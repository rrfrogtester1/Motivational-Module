def motivate_me():
    print("You are doing great! Keep moving!")
